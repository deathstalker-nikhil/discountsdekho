<?php echo $head; ?>
    <section id="merchant">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">ADVERTISE WITH US</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Brand Name</label>
                                    <input type="text" class="form-control" placeholder="Brand Name" id="name">
                                </div>
                                <div class="form-group">
                                    <label>Company Name (if any)</label>
                                    <input type="text" class="form-control" placeholder="Comapany Name" id="name">
                                </div>
                                 <div class="form-group">
                                    <label>E-Mail Address</label>
                                    <input type="text" class="form-control" placeholder="E-Mail Address" id="name">
                                </div>
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="form-control" placeholder="Name" id="name">
                                </div>
                                 <div class="form-group">
                                    <label>Mobile Number</label>
                                    <input type="text" class="form-control" placeholder="Mobile Number" id="name">
                                </div>
                                <div class="form-group">
                                    <label>Link (if any)</label>
                                    <input type="text" class="form-control" placeholder="Link" id="name">
                                </div>
                                <div class="form-group">
                                   
                                   <button class="btn btn-xl1" style="float:right;">Send Enquiry</button>
                                </div>
                              
                            </div>
                            <div class="col-md-6" style="text-align: center;">
                                    <img src="/assets/img/advertise.png">
                                    <p>You can also drop us a mail at <strong>advertise@discountsdekho.com</strong></p>
                                
                            </div>
                           </div>
                           <div class="row">
                           </div> 
                            <div class="clearfix"></div>
                        
                </div>
            </div>
        </div>
    </section>
<?php
    echo $foot;
?>

    <!-- Portfolio Modals -->
    <!-- Use the modals below to showcase details about your portfolio projects! -->

  
    <!-- jQuery -->
    <script src="/assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/assets/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="/assets/js/classie.js"></script>
    <script src="/assets/js/cbpAnimatedHeader.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="/assets/js/jqBootstrapValidation.js"></script>
    <script src="/assets/js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="/assets/js/agency.js"></script>

</body>

</html>
